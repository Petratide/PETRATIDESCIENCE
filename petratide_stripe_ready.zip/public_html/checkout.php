<?php require_once('../config.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Checkout</title>
  <script src="https://js.stripe.com/v3"></script>
  <style>
    body{font-family:Arial, sans-serif;background:#f8f9fb;padding:40px;text-align:center}
    #card-element{max-width:340px;margin:12px auto;padding:12px;border:1px solid #ddd;border-radius:8px;background:#fff}
    button{padding:10px 18px;border:0;border-radius:8px;background:#6a1b9a;color:#fff;cursor:pointer}
    button:disabled{opacity:0.6;cursor:not-allowed}
    #msg{margin-top:12px;color:#555}
  </style>
</head>
<body>
  <h2>Card Payment</h2>
  <div id="card-element"></div>
  <button id="payBtn">Pay</button>
  <div id="msg"></div>

  <script>
    const stripe = Stripe("<?php echo STRIPE_PUBLISHABLE_KEY; ?>");
    const elements = stripe.elements();
    const card = elements.create('card');
    card.mount('#card-element');

    async function pay() {
      document.getElementById('payBtn').disabled = true;
      const params = new URLSearchParams(window.location.search);
      const amount = parseInt(params.get('amount') || '2000', 10); // default $20

      const res = await fetch('payment.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({amount})
      });
      const data = await res.json();
      if (!res.ok) {
        document.getElementById('msg').textContent = data.error || 'Server error';
        document.getElementById('payBtn').disabled = false;
        return;
      }

      const {error} = await stripe.confirmCardPayment(data.clientSecret, {
        payment_method: {card}
      });

      if (error) {
        document.getElementById('msg').textContent = error.message;
        document.getElementById('payBtn').disabled = false;
      } else {
        window.location.href = 'success.html';
      }
    }

    document.getElementById('payBtn').onclick = pay;
  </script>
</body>
</html>
