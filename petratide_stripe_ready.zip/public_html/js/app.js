(() => {
  const PRODUCTS = [
    {id:'amino1mq50',name:'5-Amino-1MQ',dose:'50mg/vial',cat:'—',price:35,img:''},
    {id:'water30',name:'Bacteriostatic Water',dose:'30ml',cat:'—',price:20,img:''},
    {id:'bpc10',name:'BPC-157',dose:'10mg/vial',cat:'—',price:30,img:''},
    {id:'cagril5',name:'Cagrilintide',dose:'5mg/vial',cat:'—',price:38,img:''},
    {id:'cjcipa10',name:'CJC-1295 (no DAC) + Ipamorelin',dose:'10mg/vial',cat:'—',price:45,img:''},
    {id:'epith10',name:'Epithalon',dose:'10mg/vial',cat:'—',price:22,img:''},
    {id:'ghk50',name:'GHK-Cu',dose:'50mg/vial',cat:'—',price:25,img:''},
    {id:'ghk100',name:'GHK-Cu',dose:'100mg/vial',cat:'—',price:35,img:''},
    {id:'glut1500',name:'Glutathione',dose:'1500mg/vial',cat:'—',price:40,img:''},
    {id:'igf1lr3_1',name:'IGF-1LR3',dose:'1mg/vial',cat:'—',price:45,img:''},
    {id:'ipa5',name:'Ipamorelin',dose:'5mg/vial',cat:'—',price:18,img:''},
    {id:'klow80',name:'KLOW',dose:'80mg/vial',cat:'—',price:65,img:''},
    {id:'melan2_10',name:'Melanotan II',dose:'10mg/vial',cat:'—',price:20,img:''},
    {id:'motsc40',name:'MOTS-C',dose:'40mg/vial',cat:'—',price:48,img:''},
    {id:'nad500',name:'NAD+',dose:'500mg/vial',cat:'—',price:32,img:''},
    {id:'pt141_10',name:'PT-141',dose:'10mg/vial',cat:'—',price:20,img:''},
    {id:'reta10',name:'Reta',dose:'10mg/vial',cat:'—',price:30,img:''},
    {id:'reta15',name:'Reta',dose:'15mg/vial',cat:'—',price:35,img:''},
    {id:'reta20',name:'Reta',dose:'20mg/vial',cat:'—',price:50,img:''},
    {id:'reta30',name:'Reta',dose:'30mg/vial',cat:'—',price:70,img:''},
    {id:'semax5',name:'Semax',dose:'5mg/vial',cat:'—',price:20,img:''},
    {id:'selank10',name:'Selank',dose:'10mg/vial',cat:'—',price:30,img:''},
    {id:'sermo10',name:'Sermorelin',dose:'10mg/vial',cat:'—',price:30,img:''},
    {id:'ss31_10',name:'SS-31',dose:'10mg/vial',cat:'—',price:25,img:''},
    {id:'tb500bpc10',name:'TB-500 + BPC-157',dose:'10mg/vial',cat:'—',price:40,img:''},
    {id:'tesa10',name:'Tesamorelin',dose:'10mg/vial',cat:'—',price:50,img:''},
    {id:'tirz30',name:'Tirz',dose:'30mg/vial',cat:'—',price:40,img:''},
    {id:'tirz60',name:'Tirz',dose:'60mg/vial',cat:'—',price:60,img:''}
  ];

  const productGrid = document.getElementById('productGrid');

  // Quick Look
  const qlOverlay = document.getElementById('qlOverlay');
  const qlTitle = document.getElementById('qlTitle');
  const qlDose = document.getElementById('qlDose');
  const qlBody = document.getElementById('qlBody');
  document.getElementById('qlCloseTop').addEventListener('click', () => qlOverlay.classList.remove('show'));
  qlOverlay.addEventListener('click', e => { if (e.target === qlOverlay) qlOverlay.classList.remove('show'); });

  // Cart + checkout
  const openCartBtn = document.getElementById('openCartBtn');
  const closeCartBtn = document.getElementById('closeCartBtn');
  const cart = document.getElementById('cart');
  const cartBody = document.getElementById('cartBody');
  const cartSubtotalEl = document.getElementById('cartSubtotal');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const checkoutLayer = document.getElementById('checkoutLayer');
  const checkoutClose = document.getElementById('checkoutClose');
  const orderList = document.getElementById('orderList');
  const sumSubtotal = document.getElementById('sumSubtotal');
  const sumShipping = document.getElementById('sumShipping');
  const sumTotal = document.getElementById('sumTotal');

  // Checkout fields (for validation)
  const fFirst = document.getElementById('shipFirst');
  const fLast  = document.getElementById('shipLast');
  const fEmail = document.getElementById('shipEmail');
  const fAddr  = document.getElementById('shipAddr');
  const fApt   = document.getElementById('shipApt'); // optional
  const fState = document.getElementById('shipState');
  const fZip   = document.getElementById('shipZip');
  const placeOrderBtn = document.getElementById('placeOrderBtn');

  const cartMap = new Map();
  const money = v => (v || 0).toLocaleString(undefined, { style: 'currency', currency: 'USD' });

  /* ===== Robust scroll-lock with scrollbar compensation ===== */
  let scrollLockY = 0;
  let savedPaddingRight = '';
  function getScrollbarWidth() {
    return window.innerWidth - document.documentElement.clientWidth;
  }
  function lockScroll() {
    if (document.documentElement.classList.contains('no-scroll')) return;
    scrollLockY = window.scrollY || window.pageYOffset;
    const sbw = getScrollbarWidth();
    savedPaddingRight = document.body.style.paddingRight || '';
    if (sbw > 0) document.body.style.paddingRight = sbw + 'px';

    document.documentElement.classList.add('no-scroll');
    document.body.classList.add('no-scroll');

    document.body.style.position = 'fixed';
    document.body.style.top = `-${scrollLockY}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
  }
  function unlockScroll() {
    if (!document.documentElement.classList.contains('no-scroll')) return;
    document.documentElement.classList.remove('no-scroll');
    document.body.classList.remove('no-scroll');

    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';
    document.body.style.paddingRight = savedPaddingRight;
    window.scrollTo(0, scrollLockY);
  }
  function anyOverlayOpen() {
    return cart.classList.contains('show') || checkoutLayer.classList.contains('show');
  }
  function refreshScrollLock() { anyOverlayOpen() ? lockScroll() : unlockScroll(); }

  /* ===== UI build ===== */
  function buildProducts() {
    const sorted = [...PRODUCTS].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }) || a.dose.localeCompare(b.dose)
    );
    productGrid.innerHTML = '';
    sorted.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.dataset.id = p.id;
      card.innerHTML = `
        ${p.img ? `<img class="img-slot" src="${p.img}" alt="${p.name}">` : `<span class="img-slot" aria-hidden="true"></span>`}
        <h4 class="product-title">${p.name}</h4>
        <div class="meta">
          <p class="sub">${p.dose}</p>
          <div class="price"><strong>${money(p.price)}</strong></div>
        </div>
        <div class="actions">
          <div class="qty" data-qty="${p.id}">
            <button class="qty-btn" data-step="-" aria-label="decrease">−</button>
            <div class="qty-num" data-num="${p.id}">1</div>
            <button class="qty-btn" data-step="+" aria-label="increase">+</button>
          </div>
          <button class="btn btn-primary" data-add="${p.id}">Add to Cart</button>
          <button class="btn btn-info" data-info="${p.id}">Info</button>
        </div>`;
      productGrid.appendChild(card);
    });
  }

  function openQuickLook(p) {
    qlTitle.textContent = p.name;
    qlDose.textContent = p.dose;
    qlBody.innerHTML = `<strong>Category:</strong> ${p.cat}<br><strong>Price:</strong> ${money(p.price)}`;
    qlOverlay.classList.add('show');
  }

  /* ===== Cart open/close ===== */
  function openCart() {
    cart.classList.add('show');
    cart.setAttribute('aria-hidden', 'false');
    refreshScrollLock();
  }
  function closeCart() {
    cart.classList.remove('show');
    cart.setAttribute('aria-hidden', 'true');
    refreshScrollLock();
  }
  openCartBtn.addEventListener('click', openCart);
  closeCartBtn.addEventListener('click', closeCart);

  function computeSubtotal() {
    let total = 0; for (const { p, qty } of cartMap.values()) total += (p.price || 0) * qty; return total;
  }
  function updateSubtotalDisplays() {
    const sub = computeSubtotal();
    cartSubtotalEl.textContent = money(sub);
    checkoutBtn.disabled = cartMap.size === 0;
    if (checkoutLayer.classList.contains('show')) updateCheckoutLayer();
  }

  function renderCart() {
    cartBody.innerHTML = '';
    if (cartMap.size === 0) {
      cartBody.innerHTML = `<div style="color:#888; text-align:center; padding:16px 6px;">No products in your cart - yet!</div>`;
      updateSubtotalDisplays(); return;
    }
    for (const { p, qty } of cartMap.values()) {
      const unit = p.price || 0; const line = unit * qty;
      const row = document.createElement('div');
      row.className = 'cart-item';
      row.innerHTML = `
        <div>
          <div class="cart-item-title">${p.name} <span style="color:#777; font-weight:600;">× ${qty} vials</span></div>
          <div class="cart-item-dose">${p.dose} • <strong>${money(unit)}</strong> each</div>
          <div style="margin-top:4px; font-weight:800;">Line total: ${money(line)}</div>
        </div>
        <div class="cart-ctrls">
          <div class="qty-mini" data-qtyc="${p.id}">
            <button class="qbtn-mini" data-cstep="-" aria-label="decrease">−</button>
            <div class="qnum-mini" data-cnum="${p.id}">${qty}</div>
            <button class="qbtn-mini" data-cstep="+" aria-label="increase">+</button>
          </div>
          <button class="remove" title="Remove item" data-remove="${p.id}">×</button>
        </div>`;
      cartBody.appendChild(row);
    }
    updateSubtotalDisplays();
  }

  /* ===== Checkout overlay ===== */
  function updateCheckoutLayer() {
    orderList.innerHTML = '';
    if (cartMap.size === 0) {
      orderList.innerHTML = `<div style="color:#777;">No items yet.</div>`;
    } else {
      for (const { p, qty } of cartMap.values()) {
        const lineTotal = (p.price || 0) * qty;
        const row = document.createElement('div');
        row.className = 'order-row';
        row.innerHTML = `
          <span class="left">${p.name} <span class="muted">— ${p.dose}</span> x ${qty}</span>
          <span class="dots" aria-hidden="true"></span>
          <span class="price">${money(lineTotal)}</span>`;
        orderList.appendChild(row);
      }
    }
    const sub = computeSubtotal(), ship = 8.50, total = sub + ship;
    sumSubtotal.textContent = money(sub);
    sumShipping.textContent = money(ship);
    sumTotal.textContent = money(total);
  }

  checkoutBtn.addEventListener('click', () => {
    if (checkoutBtn.disabled) return;
    updateCheckoutLayer();
    checkoutLayer.classList.add('show');
    checkoutLayer.setAttribute('aria-hidden', 'false');
    refreshScrollLock();
  });
  function closeCheckout() {
    checkoutLayer.classList.remove('show');
    checkoutLayer.setAttribute('aria-hidden', 'true');
    refreshScrollLock();
  }
  checkoutClose.addEventListener('click', closeCheckout);
  checkoutLayer.addEventListener('click', e => { if (e.target === checkoutLayer) closeCheckout(); });

  // Product grid interactions
  productGrid.addEventListener('click', e => {
    const step = e.target?.dataset?.step;
    const addId = e.target?.dataset?.add;
    const infoId = e.target?.dataset?.info;

    if (step) {
      const wrap = e.target.closest('.qty'); if (!wrap) return;
      const id = wrap.getAttribute('data-qty'); let cur = getQtyForCard(id);
      cur = step === '+' ? cur + 1 : Math.max(1, cur - 1); setQtyForCard(id, cur); return;
    }
    if (infoId) {
      const p = PRODUCTS.find(x => x.id === infoId); if (p) openQuickLook(p); return;
    }
    if (addId) {
      const p = PRODUCTS.find(x => x.id === addId); if (!p) return;
      const addQty = getQtyForCard(addId);
      if (cartMap.has(addId)) { cartMap.get(addId).qty += addQty; }
      else { cartMap.set(addId, { p, qty: addQty }); }
      renderCart();
      showToast(`${p.name} has been added to your order (x ${addQty})`);
    }
  });

  // Qty helpers
  function getQtyForCard(id) {
    const numEl = productGrid.querySelector(`.qty-num[data-num="${id}"]`);
    if (!numEl) return 1; const n = parseInt(numEl.textContent.trim(), 10);
    return isNaN(n) || n < 1 ? 1 : n;
  }
  function setQtyForCard(id, val) {
    const numEl = productGrid.querySelector(`.qty-num[data-num="${id}"]`);
    if (numEl) { numEl.textContent = String(Math.max(1, val)); }
  }

  // Remove/adjust in cart
  cartBody.addEventListener('click', e => {
    const remId = e.target?.dataset?.remove;
    if (remId) { cartMap.delete(remId); renderCart(); return; }
    const step = e.target?.dataset?.cstep;
    if (step) {
      const wrap = e.target.closest('.qty-mini'); if (!wrap) return;
      const id = wrap.getAttribute('data-qtyc'); if (!id || !cartMap.has(id)) return;
      const entry = cartMap.get(id); entry.qty = step === '+' ? entry.qty + 1 : Math.max(1, entry.qty - 1); renderCart();
    }
  });

  // Smooth scroll for Browse button
  document.getElementById('browseBtn')?.addEventListener('click', () => {
    const target = document.querySelector('#view-products');
    if (!target) return;
    const headerH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--top')) || 72;
    const y = target.getBoundingClientRect().top + window.pageYOffset - headerH + 10;
    window.scrollTo({ top: y, behavior: 'smooth' });
  });

  // Toasts
  function showToast(text) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<div>${text}</div><div class="bar"></div>`;
    document.getElementById('toasts').appendChild(t); setTimeout(() => t.remove(), 3000);
  }

  /* ======= Simple checkout validation ======= */
  const requiredFields = [fFirst, fLast, fEmail, fAddr, fState, fZip]; // shipApt is optional

  function ensureMsg(el) {
    let m = el.nextElementSibling;
    if (!m || !m.classList.contains('field-msg')) {
      m = document.createElement('div');
      m.className = 'field-msg';
      el.insertAdjacentElement('afterend', m);
    }
    return m;
  }

  function isValid(el) {
    const v = (el.value || '').trim();
    if (el === fEmail) {
      // very light email check
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
    }
    if (el === fState) return v !== '';
    return v.length > 0;
  }

  function setFieldState(el, ok, showErrorMsg) {
    el.classList.remove('error', 'success');
    const msg = ensureMsg(el);
    msg.classList.remove('error', 'success');
    if (ok) {
      el.classList.add('success');
      msg.textContent = ''; // no success text requested
    } else {
      el.classList.add('error');
      if (showErrorMsg) {
        msg.textContent = 'Required';
        msg.classList.add('error');
      } else {
        msg.textContent = '';
      }
    }
  }

  function validateAll(showErrors) {
    let allOK = true;
    requiredFields.forEach(el => {
      const ok = isValid(el);
      setFieldState(el, ok, showErrors);
      if (!ok) allOK = false;
    });
    return allOK;
  }

  // On click "test" → validate and mark fields
  placeOrderBtn?.addEventListener('click', (e) => {
    // run validation; keep the button behavior as placeholder
    const ok = validateAll(true);
    if (!ok) {
      e.preventDefault();
      showToast('Please fill out the required shipping fields.');
    }
    // NOTE: success toast removed per request
  });

  // Live validation: turn green when user fills; clear red messages while typing/changing
  [...requiredFields, fApt].forEach(el => {
    el?.addEventListener('input', () => {
      if (el === fApt) return; // optional
      const ok = isValid(el);
      setFieldState(el, ok, false);
    });
    el?.addEventListener('change', () => {
      if (el === fApt) return;
      const ok = isValid(el);
      setFieldState(el, ok, false);
    });
  });

  function init() { buildProducts(); renderCart(); }
  init();
})();