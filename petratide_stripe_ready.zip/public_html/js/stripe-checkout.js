(function(){
  // Minimal glue to redirect to standalone checkout if total exists
  const payBtn = document.getElementById('placeOrderBtn');
  const totalEl = document.getElementById('sumTotal');

  function parseDollarsToCents(txt){
    if (!txt) return 0;
    const n = parseFloat(String(txt).replace(/[^0-9.]/g,'') || '0');
    return Math.round(n*100);
  }

  payBtn?.addEventListener('click', function(){
    const cents = parseDollarsToCents(totalEl?.textContent || '');
    if (!cents || cents < 50) {
      alert('Your cart total is empty or too low.');
      return;
    }
    // Send the user to checkout.php with the amount embedded
    window.location.href = 'checkout.php?amount='+cents;
  });
})();