<?php
// payment.php - creates a PaymentIntent for the given amount (in cents)

require_once('../config.php');          // loads STRIPE_SECRET_KEY
require_once('stripe-php/init.php');    // Stripe PHP SDK

header('Content-Type: application/json');

try {
  if (!isset($_POST['amount'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing amount']);
    exit;
  }

  $amount = intval($_POST['amount']);
  if ($amount < 50) { // minimum $0.50 to avoid mistakes
    http_response_code(400);
    echo json_encode(['error' => 'Amount too small']);
    exit;
  }

  \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

  $paymentIntent = \Stripe\PaymentIntent::create([
    'amount' => $amount,
    'currency' => 'usd',
    'automatic_payment_methods' => ['enabled' => true],
    // You can pass metadata for your records
    'metadata' => [
      'source' => 'petratide_site',
    ],
  ]);

  echo json_encode(['clientSecret' => $paymentIntent->client_secret]);
} catch (\Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
}
?>
